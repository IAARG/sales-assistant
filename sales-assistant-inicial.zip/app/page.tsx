
export default function Home() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-gray-100 text-gray-800">
      <h1 className="text-3xl font-bold">Bem-vindo ao Sales Assistant</h1>
    </main>
  );
}
